'use client';

import { useState } from 'react';
import { Heart, Search, Plus, Home, User, MessageCircle, Instagram } from 'lucide-react';
import { TopNav } from '@/components/marketplace/top-nav';
import { BottomNav } from '@/components/marketplace/bottom-nav';
import { HeroSection } from '@/components/marketplace/hero-section';
import { ProductGrid } from '@/components/marketplace/product-grid';
import { SellerProfile } from '@/components/marketplace/seller-profile';

export default function Marketplace() {
  const [showProfile, setShowProfile] = useState(false);
  const [selectedSeller, setSelectedSeller] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-white">
      {/* Desktop Top Navigation */}
      <TopNav />

      {/* Main Content */}
      <main className="pb-20 md:pb-0">
        {!showProfile ? (
          <>
            {/* Hero Section */}
            <HeroSection />

            {/* Product Grid */}
            <ProductGrid onSellerClick={(sellerId) => {
              setSelectedSeller(sellerId);
              setShowProfile(true);
            }} />
          </>
        ) : (
          <SellerProfile 
            sellerId={selectedSeller || 'default'} 
            onBack={() => setShowProfile(false)} 
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav 
        onSellClick={() => {}}
        onProfileClick={() => setShowProfile(!showProfile)}
      />
    </div>
  );
}
