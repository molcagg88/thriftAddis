export function HeroSection() {
  return (
    <section className="bg-green-600 text-white py-16 md:py-24 px-4">
      <div className="max-w-7xl mx-auto text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 tracking-tight">
          Find Your Next Vibe
        </h1>
        <p className="text-base md:text-xl mb-8 opacity-90">
          Discover unique, curated vintage and thrifted items from independent sellers
        </p>
        <button className="bg-white text-green-600 px-8 py-3 md:py-4 border-2 border-white font-bold text-base md:text-lg hover:bg-green-50 transition-colors">
          Shop Now
        </button>
      </div>
    </section>
  );
}
