'use client';

import { useState } from 'react';
import { Heart } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  price: number;
  image: string;
  seller: string;
  sellerId: string;
}

interface ProductCardProps {
  product: Product;
  onSellerClick: () => void;
}

export function ProductCard({ product, onSellerClick }: ProductCardProps) {
  const [liked, setLiked] = useState(false);

  return (
    <div className="group border-2 border-green-600 hover:shadow-[4px_4px_0px_0px_rgba(22,163,74,1)] transition-shadow">
      {/* Image Container */}
      <div className="relative aspect-square bg-gray-100 overflow-hidden">
        <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
          <span className="text-gray-400 text-3xl">📦</span>
        </div>

        {/* Like Button */}
        <button
          onClick={() => setLiked(!liked)}
          className="absolute top-2 right-2 p-2 bg-white border-2 border-green-600 hover:bg-green-50 transition-colors"
        >
          <Heart
            size={18}
            className={`transition-colors ${liked ? 'fill-green-600 text-green-600' : 'text-green-600'}`}
          />
        </button>
      </div>

      {/* Content */}
      <div className="p-3 md:p-4 border-t-2 border-green-600">
        {/* Price - Bold & Large */}
        <div className="text-xl md:text-2xl font-bold text-green-600 mb-2">
          ${product.price}
        </div>

        {/* Title */}
        <h3 className="text-sm md:text-base font-semibold text-gray-900 mb-2 line-clamp-2">
          {product.title}
        </h3>

        {/* Seller Name - Clickable */}
        <button
          onClick={onSellerClick}
          className="text-xs md:text-sm text-green-600 font-bold hover:underline"
        >
          {product.seller}
        </button>
      </div>
    </div>
  );
}
