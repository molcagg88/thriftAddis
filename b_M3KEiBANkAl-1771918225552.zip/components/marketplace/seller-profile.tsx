'use client';

import { ArrowLeft, MessageCircle, Instagram } from 'lucide-react';
import { ProductCard } from './product-card';

interface SellerProfileProps {
  sellerId: string;
  onBack: () => void;
}

const sellerData: Record<string, { name: string; handle: string; bio: string; image: string }> = {
  seller1: { name: 'Maya', handle: '@thrifted.dreams', bio: '✨ Vintage collector & sustainable fashion advocate. Curating unique pieces for the conscious consumer.', image: '👩‍🦰' },
  seller2: { name: 'Alex', handle: '@streetvibe', bio: '🎨 Street style enthusiast. Finding gems for your everyday wardrobe. DM for custom requests!', image: '👨' },
  seller3: { name: 'Jordan', handle: '@denim.collector', bio: '👖 Denim specialist. Restoring & reselling quality pieces. Built different.', image: '👕' },
  seller4: { name: 'Riley', handle: '@gen.z.closet', bio: '💚 Gen-Z style curator. Y2K nostalgia meets modern vibes.', image: '👗' },
  seller5: { name: 'Casey', handle: '@retro.fits', bio: '🔥 90s & early 2000s archive. Everything you need for the perfect retro fit.', image: '🎽' },
};

const sellerProducts = [
  { id: '1', title: 'Vintage Band Tee - Nirvana', price: 45, image: '/products/1.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
  { id: '2', title: 'Vintage Band Tee - The Smiths', price: 48, image: '/products/1b.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
  { id: '3', title: 'Carhartt Brown Jacket', price: 85, image: '/products/2.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
  { id: '4', title: 'Baggy Cargo Pants', price: 55, image: '/products/4.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
  { id: '5', title: 'Vintage Windbreaker - Yellow', price: 62, image: '/products/9.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
  { id: '6', title: 'Oversized Green Jacket', price: 75, image: '/products/10.jpg', seller: '@thrifted.dreams', sellerId: 'seller1' },
];

export function SellerProfile({ sellerId, onBack }: SellerProfileProps) {
  const seller = sellerData[sellerId] || sellerData['seller1'];

  return (
    <div className="min-h-screen">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 md:top-6 md:left-6 z-40 p-2 md:p-3 border-2 border-green-600 bg-white hover:bg-green-50 transition-colors"
      >
        <ArrowLeft size={24} className="text-green-600" />
      </button>

      {/* Seller Header */}
      <section className="pt-20 md:pt-8 px-4 md:px-6 py-8 md:py-12 bg-white border-b-2 border-green-600">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-6 items-start md:items-center">
          {/* Avatar */}
          <div className="w-24 h-24 md:w-32 md:h-32 flex-shrink-0 border-2 border-green-600 flex items-center justify-center bg-gray-100 text-5xl">
            {seller.image}
          </div>

          {/* Info */}
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">{seller.name}</h1>
            <p className="text-base md:text-lg text-green-600 font-bold mb-3">{seller.handle}</p>
            <p className="text-sm md:text-base text-gray-600 mb-6">{seller.bio}</p>

            {/* Contact Buttons */}
            <div className="flex flex-col gap-3">
              <button className="w-full md:w-auto px-6 py-3 border-2 border-green-600 bg-white text-green-600 font-bold hover:bg-green-50 transition-colors flex items-center justify-center gap-2">
                <MessageCircle size={20} />
                Contact on WhatsApp
              </button>
              <button className="w-full md:w-auto px-6 py-3 border-2 border-green-600 bg-white text-green-600 font-bold hover:bg-green-50 transition-colors flex items-center justify-center gap-2">
                <Instagram size={20} />
                Follow on Instagram
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Seller's Products */}
      <section className="px-4 md:px-6 py-12 md:py-16">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-green-600 mb-8 border-b-2 border-green-600 pb-4">
            {seller.name}'s Shop
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {sellerProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product}
                onSellerClick={() => {}}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
